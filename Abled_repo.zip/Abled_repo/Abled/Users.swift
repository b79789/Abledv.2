//
//  Users.swift
//  Abled
//
//  Created by Brian Stacks on 8/15/16.
//  Copyright © 2016 Brian Stacks. All rights reserved.
//

import Foundation
import UIKit

class Users {
    var name = String()
    var id = String()
    var followed = Bool()
    var url = NSURL()
    
}
