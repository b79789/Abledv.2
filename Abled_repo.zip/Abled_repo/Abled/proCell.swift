//
//  proCell.swift
//  Abled
//
//  Created by Brian Stacks on 8/14/16.
//  Copyright © 2016 Brian Stacks. All rights reserved.
//

import UIKit

class proCell: UITableViewCell {
    
    @IBOutlet weak var cellImage: UIImageView!
    

}
